<?php

namespace PhpAmqpLib;

final class Package
{
    const NAME = 'AMQPLib';
    const VERSION = '2.11.1';
}
